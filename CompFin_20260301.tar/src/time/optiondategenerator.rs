use std::collections::HashSet;
use std::sync::Arc;

use chrono::NaiveDate;

use crate::market::market::Market;
use crate::time::businessdayadjuster::BusinessDayAdjuster;
use crate::time::period::{
    Period,
    TimeUnit
};


#[derive(Clone, Copy, PartialEq, Eq)]
pub enum ExpiryRule {
    ExpiryToDelivery,
    DeliveryToExpiry
}

struct OptionDateGenerator {
    market: Arc<dyn Market>,
    short_term_expiry_rule: ExpiryRule,
    short_term_adjuster: BusinessDayAdjuster,
    long_term_expiry_rule: ExpiryRule,
    long_term_adjuster: BusinessDayAdjuster,
    short_term_time_unit: HashSet<TimeUnit>,
    short_term_expiry_generator: fn(NaiveDate, Period, &Arc<dyn Market>, &BusinessDayAdjuster) -> NaiveDate,
    short_term_delivery_generator: fn(NaiveDate, Period, &Arc<dyn Market>, &BusinessDayAdjuster) -> NaiveDate,
    long_term_expiry_generator: fn(NaiveDate, Period, &Arc<dyn Market>, &BusinessDayAdjuster) -> NaiveDate,
    long_term_delivery_generator: fn(NaiveDate, Period, &Arc<dyn Market>, &BusinessDayAdjuster) -> NaiveDate
}

fn generate_expiry_directly(
    horizon: NaiveDate, 
    tenor: Period, 
    market: &Arc<dyn Market>,
    adjuster: &BusinessDayAdjuster
) -> NaiveDate {
    adjuster.from_tenor_to_date(horizon, tenor, &market.expiry_calendar())
}

fn generate_delivery_directly(
    horizon: NaiveDate, 
    tenor: Period, 
    market: &Arc<dyn Market>,
    adjuster: &BusinessDayAdjuster
) -> NaiveDate {
    let spot_date = market.settlement_date(horizon);
    adjuster.from_tenor_to_date(spot_date, tenor, &market.settlement_calendar())
}

fn generate_expiry_from_delivery(
    horizon: NaiveDate, 
    tenor: Period, 
    market: &Arc<dyn Market>,
    adjuster: &BusinessDayAdjuster
) -> NaiveDate {
    let delivery_date = generate_delivery_directly(horizon, tenor, &market, adjuster);
    market.expiry_calendar().shift_n_business_day(delivery_date, -(market.settlement_days() as i32))
}

fn generate_delivery_from_expiry(
    horizon: NaiveDate, 
    tenor: Period, 
    market: &Arc<dyn Market>,
    adjuster: &BusinessDayAdjuster
) -> NaiveDate {
    let expiry_date = generate_expiry_directly(horizon, tenor, &market, adjuster);
    market.settlement_calendar().shift_n_business_day(expiry_date, market.settlement_days() as i32)
}

fn get_delivery_generator(rule: ExpiryRule) -> fn(NaiveDate, Period, &Arc<dyn Market>, &BusinessDayAdjuster) -> NaiveDate {
    match rule {
        ExpiryRule::ExpiryToDelivery => generate_delivery_from_expiry,
        ExpiryRule::DeliveryToExpiry => generate_delivery_directly
    }
}

fn get_expiry_generator(rule: ExpiryRule) -> fn(NaiveDate, Period, &Arc<dyn Market>, &BusinessDayAdjuster) -> NaiveDate {
    match rule {
        ExpiryRule::ExpiryToDelivery => generate_expiry_directly,
        ExpiryRule::DeliveryToExpiry => generate_expiry_from_delivery
    }
}

impl OptionDateGenerator {
    pub fn new(market: Arc<dyn Market>,
               short_term_expiry_rule: ExpiryRule,
               short_term_adjuster: BusinessDayAdjuster,
               long_term_expiry_rule: ExpiryRule,
               long_term_adjuster: BusinessDayAdjuster,
               short_term_time_unit: HashSet<TimeUnit>) -> Self {

        Self {
            market,
            short_term_expiry_rule,
            short_term_adjuster,
            long_term_expiry_rule,
            long_term_adjuster,
            short_term_time_unit,
            short_term_expiry_generator: get_expiry_generator(short_term_expiry_rule),
            short_term_delivery_generator: get_delivery_generator(short_term_expiry_rule),
            long_term_expiry_generator: get_expiry_generator(long_term_expiry_rule),
            long_term_delivery_generator: get_delivery_generator(long_term_expiry_rule)
        }
    }

    pub fn generate_expiry(&self, horizon: NaiveDate, tenor: Period) -> NaiveDate {
        if self.short_term_time_unit.contains(&tenor.unit()) {
            (self.short_term_expiry_generator)(horizon, tenor, &self.market, &self.short_term_adjuster)
        } else {
            (self.long_term_expiry_generator)(horizon, tenor, &self.market, &self.long_term_adjuster)
        }
    }

    pub fn generate_delivery(&self, horizon: NaiveDate, tenor: Period) -> NaiveDate {
        if self.short_term_time_unit.contains(&tenor.unit()) {
            (self.short_term_delivery_generator)(horizon, tenor, &self.market, &self.short_term_adjuster)
        } else {
            (self.long_term_delivery_generator)(horizon, tenor, &self.market, &self.long_term_adjuster)
        }
    }
}
